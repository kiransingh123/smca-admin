/* iMPORT all the class */
import express from 'express'
import router from './route/web.js'
import {join} from "path"

/* define the variables */
const app = express()
const port = process.env.PORT || '5000'

/* logic building */
app.use('/', router);
app.set('view engine','ejs');


/* call bootstrap  css and other css and public folder*/

// console.log(join(process.cwd(),'views','home.html'));
app.use(express.static(join(process.cwd(),"public")))
app.use(express.static(join(process.cwd(),"public/dist")))
app.use(express.static(join(process.cwd(),"public/dist/img")))
app.use(express.static(join(process.cwd(),"public/plugins")))
app.use(express.static(join(process.cwd(), 'node_modules/bootstrap/dist/css')))
app.use(express.static(join(process.cwd(), 'node_modules/bootstrap/dist/js')))


/* server connect */
app.listen(port, ()=>{
    console.log(`localhost connect with the port:${port}`)
})
