import {join} from "path"

let employee = (req, res)=>{

res.render('employee');
}

let employeeDetail = (req, res)=>{
    res.render('employeeDetail');
}
let employeeSalary = (req, res)=>{
    res.render('employeeSalary');
}
export {employee, employeeDetail, employeeSalary}