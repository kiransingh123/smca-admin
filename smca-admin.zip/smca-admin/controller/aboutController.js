import {join} from "path"
let about = (req, res)=>{
    // res.send('This is about page')
    res.render('about');
    }
    
    export  {about}