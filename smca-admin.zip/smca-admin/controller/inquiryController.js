import {join} from "path"

let inquiry = (req, res)=>{

// console.log(join(process.cwd(),'views','home.html'));
// console.log(process.cwd())
// res.send('This is home page')
res.render('inquiry');
}

export {inquiry}