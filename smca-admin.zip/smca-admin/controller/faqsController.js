import {join} from "path"

let faqs = (req, res)=>{
res.render('faqs');
}

let faqsAdd = (req, res)=>{
    res.render('faqsAdd');
    }
export {faqs, faqsAdd}
