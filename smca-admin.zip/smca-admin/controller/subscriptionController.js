import {join} from "path"

let subscription = (req, res)=>{
res.render('subscription');
}

export {subscription}