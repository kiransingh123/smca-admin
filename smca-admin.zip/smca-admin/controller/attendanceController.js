import {join} from "path"

let attendance = (req, res)=>{

res.render('attendance');
}


export {attendance}