import {join} from "path"

let blog = (req, res)=>{

res.render('blog');
}

let blogAdd = (req, res)=>{
    res.render('blogAdd');
}

export {blog, blogAdd}





