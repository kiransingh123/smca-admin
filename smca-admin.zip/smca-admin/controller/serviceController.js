import {join} from "path"

let service = (req, res)=>{

res.render('service');
}

let serviceAdd = (req, res)=>{
    res.render('serviceAdd');
}
export {service, serviceAdd}





