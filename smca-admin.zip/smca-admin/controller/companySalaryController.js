import {join} from "path"

let companySalary = (req, res)=>{
res.render('companySalary');
}

export {companySalary}