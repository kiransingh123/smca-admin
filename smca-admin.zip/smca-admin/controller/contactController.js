import {join} from "path"

let contact = (req, res)=>{
res.render('contact');
}

let contactMail = (req, res)=>{
res.render('contactMail');
}

export {contact, contactMail}